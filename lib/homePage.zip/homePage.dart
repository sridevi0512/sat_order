import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:sat_order_app/addItems.dart';
import 'package:sat_order_app/data/productCategory.dart';
import 'package:sat_order_app/data/shopName.dart';
import 'package:sat_order_app/utils/apiUrl.dart';
import 'package:sat_order_app/utils/constants.dart';
import 'package:sat_order_app/utils/preference.dart';
import 'package:http/http.dart' as http;

import 'data/productName.dart';

class HomePage extends StatefulWidget {
  HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}


class _HomePageState extends State<HomePage> {
  String currentTime = '';
  String userName = "", selectLine = '', selectShop = '', selectDay = '';
  String? dropDownLineValue;
  String? dropDownDayValue;
  String? dropDownShopValue;
  List<ShopName> _shopName = [];
  List<ProductCategory> _category = [];
  List<String> QuantityListItem = [];
  List<String> priceListItem = [];
  List<String> costListItem = [];
  List<TextEditingController> quantitycontroller = [];
  List<TextEditingController> pricecontroller = [];
  TextEditingController quantity = new TextEditingController();
  TextEditingController price = new TextEditingController();
  List<ProductName> dropdownlist = [];
  List<String> dropList =[];
  int shopitems = 1;
  bool check = false;
  var totalSum;
  String? selectItem;
  List<bool>? _isChecked;
  int index1 = 0;

//product dropdown list
  Future<String?> selectProduct(var category_id) async {
    print(ApiUrl.BASE_URL + ApiUrl.Product);
    String basicAuth = 'Basic ' + base64Encode(utf8.encode(Constants.AUTH_USERNAME + ':' + Constants.AUTH_PASSWORD ));
    print(basicAuth);
    final queryParameters = {
      'category': category_id,
    }.map((key, value) => MapEntry(key, value.toString()));
    var url = Uri.parse(ApiUrl.BASE_URL + ApiUrl.Product);
    final newURI = url.replace(queryParameters: queryParameters);
    print(newURI);
    var response = await http.get(newURI, headers: {
      'Authorization': basicAuth,

    });
    try{
      var data = json.decode(response.body);
      print(data);
      dropdownlist = (data).map<ProductName>((item) => ProductName.fromJson(item)).toList();



    }catch(Exception){
      FocusScope.of(context).requestFocus(new FocusNode());
      Fluttertoast.showToast(msg: "The Server is temporarily unable to service your request",
          gravity: ToastGravity.BOTTOM,
          toastLength: Toast.LENGTH_SHORT);
    }
  }

//shops dropdown item
  Future<String?> selectShops() async{
    print(ApiUrl.BASE_URL + ApiUrl.Shops);
    String basicAuth = 'Basic ' + base64Encode(utf8.encode(Constants.AUTH_USERNAME + ':' + Constants.AUTH_PASSWORD ));
    print(basicAuth);

    final response = await http.get(Uri.parse(ApiUrl.BASE_URL + ApiUrl.Shops),
      headers: <String,String> {'authorization' : basicAuth},);
    try {
      var data = json.decode(response.body);
      _shopName = (data).map<ShopName>((item) => ShopName.fromJson(item)).toList();
    }catch(Exception){
      FocusScope.of(context).requestFocus(new FocusNode());
      Fluttertoast.showToast(msg: "The Server is temporarily unable to service your request",
          gravity: ToastGravity.BOTTOM,
          toastLength: Toast.LENGTH_SHORT);
    }
  }

  // product category
  Future<String?> selectProductCategories() async{
    print(ApiUrl.BASE_URL + ApiUrl.Product_Category);
    String basicAuth = 'Basic ' + base64Encode(utf8.encode(Constants.AUTH_USERNAME + ':' + Constants.AUTH_PASSWORD ));
    print(basicAuth);

    final response = await http.get(Uri.parse(ApiUrl.BASE_URL + ApiUrl.Product_Category),
      headers: <String,String> {'authorization' : basicAuth},);
    try {
      var data = json.decode(response.body);
      print("ProductCategories $data");
      setState(() {
        _category = (data).map<ProductCategory>((item) => ProductCategory.fromJson(item)).toList();
        _isChecked = List<bool>.filled(_category.length, false);
      });


    }catch(Exception){
      FocusScope.of(context).requestFocus(new FocusNode());
      Fluttertoast.showToast(msg: "The Server is temporarily unable to service your request",
          gravity: ToastGravity.BOTTOM,
          toastLength: Toast.LENGTH_SHORT);
    }
  }


  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  List<String> lineItems = [
    'Line A',
    'Line B',
    'Line C',
    'Line D',
  ];
  List<String> dayItems = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
//add list item
  addItems() {
    setState(() {
      shopitems = shopitems +1 ;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark
    ));
    setState(() {
      currentTime = DateFormat.jm().format(DateTime.now());
      userName = (Preference.getUserName(Constants.USER_NAME)== null) ? "": Preference.getUserName(Constants.USER_NAME);
      print("user_name $userName");
    });
    selectShops();
    selectProductCategories();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {


    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
          drawer:
          Drawer(

            //side navigation bar
            child: Center(
              child:ListView(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                children: [

                  ListTile(
                    title: Center(
                        child:Text(
                          "Home",
                          style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 18,
                              fontWeight: FontWeight.w600),)),
                    onTap: (){
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: Center(
                        child:Text('New Order',
                          style: TextStyle(
                              color: Colors.grey[600],
                              fontWeight: FontWeight.w600,
                              fontSize: 18
                          ),)
                    ),
                    onTap: (){
                      Navigator.pop(context);
                    },

                  ),
                  ListTile(
                    title: Center(child:Text('My Order',
                      style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 18,
                          fontWeight: FontWeight.w600
                      ),)),
                    onTap: (){
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: Center(child:Text('Add Shop',
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 18,
                          color: Colors.grey[600]
                      ),)
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: Center(
                        child: Text('Settings',
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Colors.grey[600]
                          ),
                        )
                    ),
                    onTap: (){
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: Center(
                        child:Text('Logout',
                          style: TextStyle(
                              color: Colors.grey[600],
                              fontWeight: FontWeight.w600,
                              fontSize: 18
                          ),)),
                    onTap: (){
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: Align(
                      alignment: Alignment.bottomRight,
                      child: IconButton(
                          onPressed: (){Navigator.pop(context);},
                          icon:Icon(Icons.cancel_outlined,
                            size: 25,
                            color: Colors.grey[600],
                          )
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),

          body:
          Container(
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Row(
                                  children: [
                                    IconButton(
                                      onPressed:(){
                                        _scaffoldKey.currentState!.openDrawer();
                                      },
                                      icon:Icon(Icons.sort),
                                      color: Colors.grey[500],
                                      iconSize: 30,
                                    ),
                                    Spacer(),
                                    Column(
                                      children:[
                                        Padding(
                                          padding: EdgeInsets.only(left: 10,right: 20),
                                          child:Text(
                                            "Welcome $userName!",
                                            style: TextStyle(
                                                color: Colors.grey[500],
                                                fontWeight: FontWeight.w600,
                                                fontSize: 18
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(left: 10,right: 20),
                                          child: Text(
                                            currentTime.toString(),
                                            style: TextStyle(
                                                color: Colors.grey[500],
                                                fontSize: 18,
                                                fontWeight: FontWeight.w600
                                            ),
                                          ),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                                Padding(
                                    padding: EdgeInsets.all(20),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

                                      children:[
                                        SizedBox(
                                          height: 20.0,
                                        ),

                                        //select line
                                        Flexible(
                                          child: DecoratedBox(
                                            decoration: BoxDecoration(
                                                color: Colors.grey.shade50,
                                                borderRadius: BorderRadius.circular(5),
                                                boxShadow: <BoxShadow>[
                                                  BoxShadow(
                                                      color: /*Color.fromRGBO(0, 0, 0, 0.25)*/Colors.grey.shade300,
                                                      spreadRadius: 0.0,
                                                      blurRadius: 3,
                                                      offset: Offset(3.0,3.0)
                                                  ),
                                                  BoxShadow(
                                                      color: Colors.grey.shade400,
                                                      spreadRadius: 0.0,
                                                      blurRadius: 3/2,
                                                      offset: Offset(3.0,3.0)
                                                  ),
                                                  BoxShadow(
                                                      color: Colors.white,
                                                      spreadRadius: 2.0,
                                                      blurRadius: 3,
                                                      offset: Offset(-3.0,-3.0)
                                                  ),
                                                  BoxShadow(
                                                      color: Colors.white,
                                                      spreadRadius: 2.0,
                                                      blurRadius: 3/2,
                                                      offset: Offset(-3.0,-3.0)
                                                  )
                                                ]
                                            ),
                                            child: Padding(
                                                padding: EdgeInsets.only(left:20,right: 20),

                                                child:DropdownButton(
                                                    isExpanded: true,
                                                    hint: dropDownLineValue == null ?Text(
                                                      'Select Line',
                                                      style:
                                                      TextStyle(
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 18,
                                                          color: Colors.grey[600]),) :
                                                    Text(
                                                        dropDownLineValue!,
                                                        style:
                                                        TextStyle(
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 18,
                                                            color: Colors.grey[600])),
                                                    icon: Image.asset('images/downarrow.png'),
                                                    underline: Container(),
                                                    items: lineItems.map((e) {
                                                      return DropdownMenuItem(
                                                          value: e,
                                                          child: Container(
                                                            child:Text(e,
                                                              style: TextStyle(
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 17,
                                                                  color: Colors.grey[600]
                                                              ) ,),
                                                          )
                                                      );
                                                    }).toList(),
                                                    onChanged: (String? newValue) {
                                                      setState(() {
                                                        dropDownLineValue = newValue!;
                                                        selectLine = dropDownLineValue!;
                                                        print("selectLine $selectLine");
                                                      });
                                                    })
                                            ),
                                          ),
                                        ),

                                        //select day
                                        SizedBox(width: 10),
                                        Flexible(
                                          child:DecoratedBox(
                                            decoration: BoxDecoration(
                                                color: Colors.grey.shade50,
                                                borderRadius: BorderRadius.circular(5),
                                                boxShadow: <BoxShadow>[
                                                  BoxShadow(
                                                      color: /*Color.fromRGBO(0, 0, 0, 0.25)*/ Colors.grey.shade300,
                                                      spreadRadius: 0.0,
                                                      blurRadius: 3,
                                                      offset: Offset(3.0,3.0)
                                                  ),
                                                  BoxShadow(
                                                      color: Colors.grey.shade400,
                                                      spreadRadius: 0.0,
                                                      blurRadius: 3/2,
                                                      offset: Offset(3.0,3.0)
                                                  ),
                                                  BoxShadow(
                                                      color: Colors.white,
                                                      spreadRadius: 2.0,
                                                      blurRadius: 3,
                                                      offset: Offset(-3.0,-3.0)
                                                  ),
                                                  BoxShadow(
                                                      color: Colors.white,
                                                      spreadRadius: 2,
                                                      blurRadius: 3/2,
                                                      offset: Offset(-3.0,-3.0)
                                                  )
                                                ]
                                            ),
                                            child:Padding(
                                                padding: EdgeInsets.only(left: 20,right: 20),
                                                child:DropdownButton(
                                                  isExpanded: true,
                                                  underline: Container(),
                                                  hint: dropDownDayValue == null ? Text(
                                                      'Select Day',
                                                      style:
                                                      TextStyle(
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 18,
                                                          color: Colors.grey[600])) :
                                                  Text(
                                                      dropDownDayValue!,
                                                      style:
                                                      TextStyle(
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 18,
                                                          color: Colors.grey[600])),
                                                  icon: Image.asset('images/downarrow.png'),
                                                  items: dayItems.map((items) {
                                                    return DropdownMenuItem(
                                                      value: items,
                                                      child: Text(items,
                                                        style: TextStyle(
                                                            fontSize: 17,
                                                            fontWeight: FontWeight.w600,
                                                            color: Colors.grey[600]
                                                        ),),
                                                    );
                                                  }).toList(),
                                                  onChanged: (String? value) {
                                                    setState(() {
                                                      dropDownDayValue = value!;
                                                      selectDay = dropDownDayValue!;
                                                      print("selectDay $selectDay");
                                                    });
                                                  },
                                                )
                                            ),
                                          ),
                                        )
                                      ],
                                    )
                                ),

                                //select shop
                                Flexible(
                                    child:Padding(
                                      padding: EdgeInsets.only(left: 20,right: 20,top: 10,bottom: 10),
                                      child:DecoratedBox(
                                        decoration: BoxDecoration(
                                            color: Colors.grey.shade50,
                                            borderRadius: BorderRadius.circular(5),
                                            boxShadow: <BoxShadow>[
                                              BoxShadow(
                                                  color: /*Color.fromRGBO(0, 0, 0, 0.25)*/ Colors.grey.shade300,
                                                  spreadRadius: 0.0,
                                                  blurRadius: 3,
                                                  offset: Offset(3.0,3.0)
                                              ),
                                              BoxShadow(
                                                  color: Colors.grey.shade400,
                                                  spreadRadius: 0.0,
                                                  blurRadius: 3/2,
                                                  offset: Offset(3.0,3.0)
                                              ),
                                              BoxShadow(
                                                  color: Colors.white,
                                                  spreadRadius: 2.0,
                                                  blurRadius: 3,
                                                  offset: Offset(-3.0,-3.0)
                                              ),
                                              BoxShadow(
                                                  color: Colors.white,
                                                  spreadRadius: 2.0,
                                                  blurRadius: 3/2,
                                                  offset: Offset(-3.0,-3.0)
                                              )
                                            ]
                                        ),
                                        child: Padding(
                                          padding: EdgeInsets.only(left: 20,right: 20),

                                          child: DropdownButton(
                                            isExpanded: true,
                                            underline: Container(),
                                            icon: Image.asset("images/downarrow.png"),
                                            hint: dropDownShopValue == null ? Center(
                                                child:Text('Select Shops',
                                                    style: TextStyle(
                                                        fontWeight: FontWeight.w600,
                                                        fontSize: 18,
                                                        color: Colors.grey[600]))) :
                                            Center(
                                                child:Text(dropDownShopValue!,
                                                    style: TextStyle(
                                                        fontWeight: FontWeight.w600,
                                                        fontSize: 18,
                                                        color: Colors.grey[600]))),
                                            items: _shopName.map((ShopName items) {
                                              return DropdownMenuItem(
                                                  value: items.shopName,
                                                  child: Center(
                                                    child:Text(items.shopName!,
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(
                                                          color: Colors.grey[600],
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 17
                                                      ),
                                                    ),
                                                  )
                                              );
                                            }).toList(),
                                            onChanged: (String? value) {
                                              setState(() {
                                                dropDownShopValue = value!;
                                                selectShop = dropDownShopValue!;
                                                print("selectShop $selectShop");
                                              });
                                            },
                                          ),


                                        ),
                                      ),
                                    )
                                ),
                                SizedBox(height: 20),

                                Padding(
                                    padding: EdgeInsets.only(left: 20,right: 20),
                                    child:Container(
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: _category.length,
                                        itemBuilder: (BuildContext context,int index){
                                          return new Row(
                                            children:[

                                              //category
                                              Expanded(
                                                child: ExpansionTile(
                                                    trailing: SizedBox.shrink(),
                                                    leading:Icon(Icons.check_box_outline_blank_outlined),
                                                    onExpansionChanged: (bool isExpanded) {
                                                      print("category_id ${_category[index].category_id}");
                                                      var category_id = _category[index].category_id;
                                                      selectProduct(category_id);
                                                       index1 = index;
                                                       print("index1 $index1");

                                                    },

                                                    children: [
                                                      Column(
                                                        children:[
                                                          Padding(padding:
                                                          EdgeInsets.all(10),
                                                              child:Row(
                                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                                children: [
                                                                  Text(
                                                                    "Item",
                                                                    style: TextStyle(
                                                                        color: Color(0xff767676),
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 16
                                                                    ),
                                                                  ),
                                                                  SizedBox(width: 10),

                                                                  Text(
                                                                    "Quantity",
                                                                    style: TextStyle(
                                                                        color: Color(0xff767676),
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 16
                                                                    ),
                                                                  ),
                                                                  SizedBox(width: 10),
                                                                  Text(
                                                                    "Price",
                                                                    style: TextStyle(
                                                                        color: Color(0xff767676),
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 16
                                                                    ),
                                                                  ),
                                                                  SizedBox(width: 10),
                                                                  Text(
                                                                    "Cost",
                                                                    style: TextStyle(
                                                                        color: Color(0xff767676),
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 16
                                                                    ),
                                                                  )
                                                                ],
                                                              )
                                                          ),
                                                          //Add and remove  product items in list
                                                          ListView.builder(
                                                            physics: NeverScrollableScrollPhysics(),
                                                            itemCount: shopitems,
                                                            shrinkWrap: true,
                                                            itemBuilder: (BuildContext context, int i) {
                                                              quantitycontroller.add(new TextEditingController());
                                                              pricecontroller.add(new TextEditingController());
                                                              //total cost
                                                              totalSum = ((quantitycontroller[i].text == '' || pricecontroller[i].text == '')? double.parse("0.0"):
                                                              (double.parse(quantitycontroller[i].text)) * double.parse(pricecontroller[i].text));
                                                              return Padding(
                                                                padding: EdgeInsets.only(bottom: 15),
                                                                child: Container(
                                                                  child: Column(
                                                                      mainAxisSize: MainAxisSize.min,
                                                                      children: [
                                                                        Row(
                                                                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                                                                          mainAxisSize: MainAxisSize.min,
                                                                          children: [
                                                                            SizedBox(width: 10),
                                                                            Flexible(
                                                                              child:DropdownButtonFormField<String>(
                                                                                isExpanded: true,
                                                                                decoration: const InputDecoration(
                                                                                  enabledBorder: OutlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                        color: Colors.grey,
                                                                                        width: 1.0),
                                                                                  ),
                                                                                  border: OutlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                        color: Colors.grey,
                                                                                        width: 1.0),
                                                                                  ),
                                                                                ),

                                                                                hint:  Center(
                                                                                    child:Text('Select',
                                                                                        style: TextStyle(
                                                                                            fontWeight: FontWeight.w600,
                                                                                            fontSize: 18,
                                                                                            color: Colors.grey[600]))),

                                                                                items: dropdownlist
                                                                                    .map((ProductName selectlist) {
                                                                                  return DropdownMenuItem<String>(
                                                                                    value: selectlist.product_name,
                                                                                    child: Text(selectlist.product_name!.toString(),
                                                                                        style: TextStyle(
                                                                                            color: Colors.grey,
                                                                                            fontSize: 18)),
                                                                                  );
                                                                                }).toList(),
                                                                                onChanged: (String? newvalue){
                                                                                  setState(() {
                                                                                    // dropList.insert(index, newvalue!);
                                                                                    print(newvalue);
                                                                                    selectItem = newvalue;
                                                                                  });

                                                                                },
                                                                                // value: this.dropList[index].toString(),

                                                                              ),
                                                                            ),
                                                                            SizedBox(width: 10),
                                                                            Expanded(
                                                                              child:TextFormField(
                                                                                autofocus: false,
                                                                                onChanged: (value){
                                                                                  QuantityListItem.insert(i, value);
                                                                                  setState(() {

                                                                                  });
                                                                                },
                                                                                controller: quantitycontroller[i],
                                                                                keyboardType: TextInputType.numberWithOptions(),
                                                                                decoration: const InputDecoration(
                                                                                    enabledBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                          color: Colors.grey,
                                                                                          width: 1.0),
                                                                                    ),
                                                                                    border: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                          color: Colors.grey,
                                                                                          width: 1.0),
                                                                                    ),
                                                                                    hintText: "Quantity",
                                                                                    hintStyle: TextStyle(
                                                                                        color: Colors.grey,
                                                                                        fontSize: 18)),
                                                                              ),
                                                                            ),
                                                                            SizedBox(width: 10),
                                                                            Expanded(
                                                                              child:TextFormField(
                                                                                autofocus: false,
                                                                                onChanged: (value){
                                                                                  priceListItem.insert(i, value);
                                                                                  setState(() {
                                                                                  });

                                                                                },
                                                                                controller: pricecontroller[i],
                                                                                keyboardType: TextInputType.number,
                                                                                decoration: const InputDecoration(
                                                                                    enabledBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                          color: Colors.grey,
                                                                                          width: 1.0),
                                                                                    ),
                                                                                    border: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                          color: Colors.grey,
                                                                                          width: 1.0),
                                                                                    ),
                                                                                    hintText: "Price",
                                                                                    hintStyle: TextStyle(
                                                                                        color: Colors.grey,
                                                                                        fontSize: 18)),
                                                                              ),
                                                                            ),
                                                                            SizedBox(width: 10),
                                                                            Expanded(
                                                                              child:Text(

                                                                                //total value
                                                                                  (pricecontroller[index].text== '' && quantitycontroller[index].text == '')?
                                                                                  ' Rs. 0':
                                                                                  "Rs. ${totalSum.toString()}"
                                                                              ),
                                                                            ),
                                                                            SizedBox(
                                                                              width: 20,
                                                                            ),
                                                                            Container(
                                                                              width: 20,
                                                                              height: 20,
                                                                              child: GestureDetector(
                                                                                onTap: (){
                                                                                  setState(() {
                                                                                    dropdownlist.removeAt(index);
                                                                                    quantitycontroller.removeAt(index);
                                                                                    pricecontroller.removeAt(index);
                                                                                    setState(() {
                                                                                      shopitems = shopitems-1;
                                                                                    });

                                                                                  });
                                                                                },
                                                                                child: Image.asset(
                                                                                    "images/minus.png"
                                                                                ),
                                                                              ),


                                                                            ),

                                                                          ],
                                                                        ),
                                                                      ]


                                                                  ),
                                                                ),

                                                              );
                                                            },
                                                          ),
                                                          ElevatedButton(
                                                            style: ElevatedButton.styleFrom(
                                                              primary: Color(0xffd8d2d2),),
                                                            onPressed: (){addItems();},
                                                            child: Text("Add Product",
                                                              style: TextStyle(
                                                                color: Color(0xffc31d1c),
                                                              ),),
                                                          ),
                                                        ],
                                                      ),

                                                    ],

                                                    title:Row(children:[
                                                      /* Checkbox(
                                                        value: _isChecked![index],
                                                        activeColor: Colors.grey,
                                                        checkColor: Colors.white,
                                                        // controlAffinity: ListTileControlAffinity.leading,
                                                        onChanged: (bool? value) {
                                                          setState(() {
                                                            _isChecked![index] = value!;
                                                            check = true;
                                                          });
                                                        },
                                                      ),*/

                                                      Text(_category[index].category_name!,)
                                                    ])

                                                ),

                                              )

                                            ],
                                          );
                                        },
                                      ),
                                    )
                                ),


                                SizedBox(height: 20),
                                Padding(
                                    padding: EdgeInsets.only(left: 20,right: 20,top: 10),
                                    child:Container(
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            boxShadow: <BoxShadow>[
                                              BoxShadow(
                                                  blurRadius: 5,
                                                  color: Color.fromRGBO(0, 0, 0, 0.25)
                                              )
                                            ]
                                        ),
                                        child: Padding(
                                          padding: EdgeInsets.all(20),
                                          child:Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Center(
                                                  child:Text(
                                                    "Total",
                                                    style: TextStyle(
                                                        fontSize: 18,
                                                        fontWeight: FontWeight.w600,
                                                        color: Colors.grey[600]
                                                    ),
                                                  )
                                              ),
                                              Column(
                                                children: [
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Text(
                                                        "Net Rs.",
                                                        style: TextStyle(
                                                            color: Colors.grey[600],
                                                            fontSize: 18,
                                                            fontWeight: FontWeight.w600
                                                        ),
                                                      ),
                                                      SizedBox(width: 10),
                                                      Text(
                                                        totalSum.toString(),
                                                        style: TextStyle(
                                                          fontWeight: FontWeight.normal,
                                                          color: Colors.black,
                                                          fontSize: 16,
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                  SizedBox(height: 5),
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Text(
                                                        "CGST Rs. ",
                                                        style: TextStyle(
                                                            color: Colors.grey[600],
                                                            fontSize: 18,
                                                            fontWeight: FontWeight.w600
                                                        ),
                                                      ),
                                                      SizedBox(width: 10),
                                                      Text(
                                                        "3.65% ",
                                                        style: TextStyle(
                                                            fontWeight: FontWeight.normal,
                                                            fontSize: 16,
                                                            color: Colors.black
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                  SizedBox(height: 5),
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Text(
                                                        "SGST Rs. ",
                                                        style: TextStyle(
                                                            color: Colors.grey[600],
                                                            fontSize: 18,
                                                            fontWeight: FontWeight.w600
                                                        ),
                                                      ),
                                                      SizedBox(width: 10),
                                                      Text(
                                                        "2.00% ",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 16,
                                                            fontWeight: FontWeight.normal
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                  SizedBox(height: 5),
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Text(
                                                        "Total Rs. ",
                                                        style: TextStyle(
                                                            color: Colors.grey[600],
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 18
                                                        ),
                                                      ),
                                                      SizedBox(width: 10),
                                                      Text(
                                                        "3000 ",
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 16,
                                                            fontWeight: FontWeight.normal
                                                        ),
                                                      )
                                                    ],
                                                  )
                                                ],
                                              )
                                            ],

                                          ),
                                        )
                                    )
                                ),
                                SizedBox(height: 20),
                                Padding(
                                    padding: EdgeInsets.all(20),
                                    child:Center(
                                        child:ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                primary: Color(0xffC61D1C),
                                                minimumSize: Size.fromHeight(50),
                                                shadowColor: Colors.black26
                                            ),
                                            onPressed: (){
                                              // getCheckboxItems();
                                              // submitData();
                                              print(QuantityListItem);
                                            },
                                            child: Text(
                                              "Place Order",
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  color: Colors.white
                                              ),
                                            ))
                                    )
                                )
                              ]
                          )
                      ),
                    ),
                  ]
              )
          ),
        )
    );

  }
}
